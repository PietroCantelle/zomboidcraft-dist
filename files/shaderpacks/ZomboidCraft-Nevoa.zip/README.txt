ZomboidCraft Névoa — shader leve do ZomboidCraft
=================================================

Shader de horror MUITO leve para Oculus 1.8.0 (Iris 1.7) no Minecraft 1.20.1.
Um passe de sombra (shadow map) + um único passe de pós-processamento
(composite) sobre a renderização vanilla: sombras diferidas, névoa exponencial
por altura, neblina rasteira com deriva lenta, paleta de horror, dessaturação,
gamma lift, contraste e vinheta suave. Sem TAA, sem bloom, sem grão de filme,
sem barras pretas.

Como funciona
-------------
- Nenhum programa gbuffers_* é definido: o Iris renderiza o mundo com os
  shaders vanilla e o pack só processa a imagem final (colortex0 + depthtex0).
- A névoa depende da hora do dia (worldTime), da chuva (rainStrength), da luz
  do céu no jogador (eyeBrightnessSmooth: cavernas/interiores ficam com névoa
  escura) e de estar debaixo d'água (isEyeInWater).
- Sombras: o passe shadow.vsh/fsh grava o shadow map; o composite reconstrói
  a posição do mundo pela profundidade e compara com shadowtex1 (PCF 4 taps),
  tingindo por shadowcolor0 quando o oclusor é translúcido. A força cai perto
  do horizonte, na chuva, em interiores (luz do céu no jogador) e à noite.
- Nether e End têm paleta própria e não têm sombras (shaders/world-1 e shaders/world1).

Arquivos
--------
shaders/shaders.properties       opções, perfis, telas
shaders/composite.vsh / .fsh     Overworld
shaders/shadow.vsh / .fsh        passe de sombra (só Overworld)
shaders/world-1/composite.*      Nether
shaders/world1/composite.*       End
shaders/lib/options.glsl         todos os #define / const ajustáveis
shaders/lib/shadow_common.glsl   distorção do shadow map (compartilhada)
shaders/lib/nevoa.glsl           o código do efeito
shaders/lang/en_US.lang          nomes das opções (inglês)
shaders/lang/pt_BR.lang          nomes das opções (português)

Build
-----
powershell -ExecutionPolicy Bypass -File C:\pietro\ZomboidCraft\shaders\build-nevoa.ps1
Gera: C:\pietro\ZomboidCraft\pack\shaderpacks\ZomboidCraft-Nevoa.zip
