#version 120

// ZomboidCraft Névoa — vértice do passe de tela cheia
varying vec2 texCoord;

void main() {
    gl_Position = ftransform();
    texCoord = gl_MultiTexCoord0.xy;
}
