// ZomboidCraft Névoa — distorção do shadow map.
// Concentra resolução perto do jogador. A MESMA função é usada no shadow.vsh
// (ao gravar o mapa) e no composite (ao consultar o mapa).

float shadowDistortFactor(vec2 xy) {
    return length(xy) * 0.9 + 0.1;
}

vec3 distortShadow(vec3 pos) {
    pos.xy /= shadowDistortFactor(pos.xy);
    pos.z  *= 0.2;
    return pos;
}
