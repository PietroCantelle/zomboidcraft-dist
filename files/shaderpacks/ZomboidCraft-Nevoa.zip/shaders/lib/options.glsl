// ZomboidCraft Névoa — opções (o Iris lê as opções a partir destas linhas #define)
// Formato: #define NOME valor // [lista de valores permitidos]

// ===== Névoa =====
#define FOG_DENSITY 1.0 // [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.5 3.0]
#define FOG_NIGHT_BOOST 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define FOG_RAIN_BOOST 0.8 // [0.0 0.25 0.5 0.75 0.8 1.0 1.5 2.0]
#define FOG_CAVE_BOOST 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define FOG_START 2.0 // [0.0 1.0 2.0 4.0 8.0 16.0]
#define FOG_DAY_PRESET 0 // [0 1 2 3]
#define FOG_NIGHT_PRESET 0 // [0 1 2 3]
#define SKY_FOG_STRENGTH 0.85 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.85 0.9 1.0]

// ===== Névoa por altura =====
#define HEIGHT_FOG
#define FOG_HEIGHT_BASE 64.0 // [-64.0 0.0 32.0 48.0 56.0 64.0 72.0 80.0 96.0 128.0 160.0 200.0]
#define FOG_HEIGHT_FALLOFF 48.0 // [16.0 24.0 32.0 48.0 64.0 96.0 128.0 256.0]

// ===== Cor =====
#define DESATURATION 0.35 // [0.0 0.1 0.2 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0]
#define GAMMA_LIFT 1.15 // [0.8 0.9 1.0 1.05 1.1 1.15 1.2 1.3 1.4 1.5 1.6]
#define CONTRAST 1.05 // [0.8 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.3]
#define COLOR_TINT
#define TINT_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0]

// ===== Tela =====
#define VIGNETTE
#define VIGNETTE_STRENGTH 0.35 // [0.0 0.1 0.2 0.3 0.35 0.4 0.45 0.5 0.6 0.7]
#define DITHER
