// ZomboidCraft Névoa — shader leve do ZomboidCraft
// Passe único de pós-processamento: lê colortex0 (cena vanilla) e depthtex0,
// aplica sombras diferidas (shadow map), névoa exponencial por altura + neblina
// rasteira, paleta de horror, dessaturação, gamma lift, contraste e vinheta
// suave. Sem TAA, sem bloom, sem grão.
//
// Incluído por composite.fsh de cada dimensão, que define antes:
//   NEVOA_OVERWORLD | NEVOA_NETHER | NEVOA_END

#include "/lib/options.glsl"
#include "/lib/shadow_common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

uniform int worldTime;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform float nightVision;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;

#if defined SHADOWS && defined NEVOA_OVERWORLD
#define NEVOA_SHADOWS
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform float sunAngle;
#endif

varying vec2 texCoord;

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

// ---- Paletas (presets) ----
#if FOG_DAY_PRESET == 1
const vec3 FOG_DAY_COLOR = vec3(0.47, 0.48, 0.50);      // Chumbo (cinza neutro)
#elif FOG_DAY_PRESET == 2
const vec3 FOG_DAY_COLOR = vec3(0.38, 0.47, 0.38);      // Pantano (verde)
#elif FOG_DAY_PRESET == 3
const vec3 FOG_DAY_COLOR = vec3(0.50, 0.46, 0.40);      // Cinza morto (sepia)
#else
const vec3 FOG_DAY_COLOR = vec3(0.46, 0.52, 0.49);      // Nevoa fria (cinza-esverdeado)
#endif

#if FOG_NIGHT_PRESET == 1
const vec3 FOG_NIGHT_COLOR = vec3(0.012, 0.012, 0.015); // Breu
#elif FOG_NIGHT_PRESET == 2
const vec3 FOG_NIGHT_COLOR = vec3(0.015, 0.045, 0.035); // Verde doentio
#elif FOG_NIGHT_PRESET == 3
const vec3 FOG_NIGHT_COLOR = vec3(0.055, 0.015, 0.012); // Sangue velho
#else
const vec3 FOG_NIGHT_COLOR = vec3(0.020, 0.035, 0.060); // Azul abissal
#endif

const vec3 FOG_CAVE_COLOR   = vec3(0.012, 0.014, 0.018);
const vec3 FOG_WATER_COLOR  = vec3(0.020, 0.080, 0.090);
const vec3 FOG_NETHER_COLOR = vec3(0.160, 0.050, 0.030);
const vec3 FOG_END_COLOR    = vec3(0.050, 0.030, 0.070);

const vec3 TINT_DAY   = vec3(0.94, 1.00, 0.97);
const vec3 TINT_NIGHT = vec3(0.86, 0.94, 1.06);

// Densidade base da nevoa: ~50% a 58 blocos com FOG_DENSITY 1.0 (de dia, fora da neblina)
const float BASE_DENSITY = 0.012;
// Densidade base da neblina rasteira (dentro da camada), multiplicada por MIST_DENSITY
const float MIST_BASE_DENSITY = 0.03;

// ---- Nevoa exponencial por altura: integral analitica ao longo do raio ----
// Perfil: densidade 1 abaixo de 'base', exp(-b*h) acima. h = altura relativa a base.
float heightAntideriv(float h, float b) {
    return h < 0.0 ? h : (1.0 - exp(-b * h)) / b;
}

float heightIntegral(float y0, float dirY, float d, float base, float b) {
    float h0 = y0 - base;
    if (abs(dirY) < 0.001) {
        return d * min(1.0, exp(-b * max(h0, 0.0)));
    }
    float h1 = h0 + d * dirY;
    return abs(heightAntideriv(h1, b) - heightAntideriv(h0, b)) / abs(dirY);
}

#ifdef NEVOA_SHADOWS
// Retorna a luz que chega (1 = iluminado, 0 = sombra), com tom de sombras translucidas.
vec3 computeShadowLight(vec3 playerPos, vec3 worldNormal, float NdotL) {
    mat4 shadowMat = shadowProjection * shadowModelView;
    vec4 spBase = shadowMat * vec4(playerPos, 1.0);

    // Fora do alcance do shadow map: sem sombra
    float distFade = 1.0 - smoothstep(0.75, 0.98, length(spBase.xy));
    if (distFade <= 0.0) return vec3(1.0);

    // Tamanho de um texel do mapa em blocos, neste ponto (depende da distorcao)
    float factor     = shadowDistortFactor(spBase.xy);
    float texelWorld = 2.0 * shadowDistance * factor / float(shadowMapResolution);

    // Normal offset (anti-acne em superficies inclinadas)
    vec3 spN = (shadowMat * vec4(worldNormal, 0.0)).xyz;
    vec3 sp  = spBase.xyz + spN * texelWorld;
    sp = distortShadow(sp) * 0.5 + 0.5;

    // Bias em profundidade: unidades de depth por bloco = |proj[2][2]| * 0.2 (escala z) * 0.5
    float depthPerBlock = abs(shadowProjection[2][2]) * 0.1;
    float bias = depthPerBlock * (0.05 + 0.75 * texelWorld);
    float zRef = sp.z - bias;

    // PCF 4 taps (so opacos: shadowtex1)
    float r = SHADOW_SOFTNESS / float(shadowMapResolution);
    float lit = 0.0;
    lit += step(zRef, texture2D(shadowtex1, sp.xy + vec2( r,  r)).r);
    lit += step(zRef, texture2D(shadowtex1, sp.xy + vec2(-r,  r)).r);
    lit += step(zRef, texture2D(shadowtex1, sp.xy + vec2( r, -r)).r);
    lit += step(zRef, texture2D(shadowtex1, sp.xy + vec2(-r, -r)).r);
    lit *= 0.25;

    // Oclusor translucido (agua, vidro): tinge em vez de escurecer
    float lit0   = step(zRef, texture2D(shadowtex0, sp.xy).r);
    float transl = max(lit - lit0, 0.0);
    vec3 tint    = texture2D(shadowcolor0, sp.xy).rgb;
    vec3 light   = vec3(lit) - transl * (vec3(1.0) - tint);

    // Faces viradas para longe da luz ficam na sombra
    light *= smoothstep(0.0, 0.1, NdotL);

    return mix(vec3(1.0), light, distFade);
}
#endif

/* DRAWBUFFERS:0 */

void main() {
    vec3 color  = texture2D(colortex0, texCoord).rgb;
    float depth = texture2D(depthtex0, texCoord).r;

    // Posicao em view-space a partir da profundidade
    vec4 viewPos = gbufferProjectionInverse * vec4(vec3(texCoord, depth) * 2.0 - 1.0, 1.0);
    viewPos.xyz /= viewPos.w;
    viewPos.w = 1.0;
    float dist = length(viewPos.xyz);
    vec3 worldDir  = normalize(mat3(gbufferModelViewInverse) * viewPos.xyz);
    vec3 playerPos = (gbufferModelViewInverse * viewPos).xyz;   // relativo a camera, eixos do mundo

#ifdef NEVOA_SHADOWS
    // Normal por derivadas de tela (fora de qualquer branch, como exige o GLSL)
    vec3 viewNormal  = normalize(cross(dFdx(viewPos.xyz), dFdy(viewPos.xyz)));
    vec3 worldNormal = mat3(gbufferModelViewInverse) * viewNormal;
#endif

    bool isSky  = depth > 0.9999;   // ceu: nada escrito no depth
    bool isHand = depth < 0.56;     // mao/item em primeira pessoa (depth comprimido pelo Iris)

    // ---- Fatores de ambiente ----
    float t = float(worldTime);
    float night = smoothstep(12000.0, 13500.0, t) * (1.0 - smoothstep(22500.0, 24000.0, t));
    float rain  = rainStrength;
    float skyLight   = float(eyeBrightnessSmooth.y) / 240.0;
    float blockLight = float(eyeBrightnessSmooth.x) / 240.0;
    float cave  = smoothstep(0.35, 1.0, 1.0 - skyLight);

    // ---- Sombras diferidas (so Overworld) ----
#ifdef NEVOA_SHADOWS
    if (!isSky && !isHand) {
        vec3 lightDir = mat3(gbufferModelViewInverse) * normalize(shadowLightPosition);
        float shadowStr = SHADOW_STRENGTH
            * smoothstep(0.08, 0.30, lightDir.y)     // some perto do horizonte
            * smoothstep(0.10, 0.80, skyLight)       // cavernas/interiores nao escurecem duas vezes
            * (1.0 - 0.8 * rain)                     // chuva: sol encoberto
            * (sunAngle > 0.5 ? 0.5 : 1.0);          // lua: sombras mais fracas
        if (shadowStr > 0.001) {
            float NdotL = dot(worldNormal, lightDir);
            vec3 light = computeShadowLight(playerPos, worldNormal, NdotL);
            color *= vec3(1.0) - shadowStr * (vec3(1.0) - light);
        }
    }
#endif

    // ---- Cor e densidade da nevoa por dimensao ----
    vec3 fogCol;
    float density;
    bool useHeight = false;
    bool useMist   = false;

#if defined NEVOA_NETHER
    fogCol  = FOG_NETHER_COLOR;
    density = BASE_DENSITY * 1.5 * FOG_DENSITY;
    night = 0.0;
    cave  = 0.0;
#elif defined NEVOA_END
    fogCol  = FOG_END_COLOR;
    density = BASE_DENSITY * 0.7 * FOG_DENSITY;
    night = 0.8;
    cave  = 0.0;
#else
    fogCol = mix(FOG_DAY_COLOR, FOG_NIGHT_COLOR, night);
    // chuva: mais cinza e um pouco mais escura
    fogCol = mix(fogCol, vec3(dot(fogCol, LUMA)) * 0.85, 0.5 * rain);
    // o reforco noturno nao se soma ao de caverna (la dentro ja e escuro)
    density = BASE_DENSITY * FOG_DENSITY
            * (1.0 + FOG_NIGHT_BOOST * night * (1.0 - cave))
            * (1.0 + FOG_RAIN_BOOST * rain);
    #ifdef HEIGHT_FOG
    useHeight = true;
    #endif
    #ifdef GROUND_MIST
    useMist = true;
    #endif
#endif

    // Cor usada no ceu (sem a mistura de caverna, para a saida da caverna continuar visivel)
    vec3 skyFogCol = fogCol;

    // Caverna / interior escuro: nevoa mais densa e quase preta; tochas perto do olho aliviam
    fogCol  = mix(fogCol, FOG_CAVE_COLOR, cave);
    density *= 1.0 + FOG_CAVE_BOOST * cave * (1.0 - 0.6 * blockLight);

    // Visao noturna reduz a nevoa
    float nvMul = 1.0 - 0.6 * nightVision;
    density *= nvMul;

    // Neblina rasteira: um pouco mais clara que a nevoa
    vec3 mistCol = mix(fogCol, vec3(dot(fogCol, LUMA)) + 0.04, 0.5);

    // Debaixo da agua
    if (isEyeInWater == 1) {
        fogCol    = FOG_WATER_COLOR;
        density   = 0.09 * FOG_DENSITY;
        useHeight = false;
        useMist   = false;
    }

    // ---- Nevoa na geometria ----
    if (!isSky && !isHand) {
        float d = max(dist - FOG_START, 0.0);

        // Camada principal
        float T1;
        if (useHeight) {
            T1 = density * heightIntegral(cameraPosition.y, worldDir.y, d, FOG_HEIGHT_BASE, 1.0 / FOG_HEIGHT_FALLOFF);
        } else {
            T1 = density * d;
        }

        // Neblina rasteira (camada baixa, com deriva lenta)
        float T2 = 0.0;
        if (useMist) {
            vec3 worldPos = cameraPosition + playerPos;
            float drift = 1.0 + 0.25 * sin(worldPos.x * 0.07 + frameTimeCounter * 0.35)
                                     * sin(worldPos.z * 0.05 - frameTimeCounter * 0.25);
            float mistDensity = MIST_BASE_DENSITY * MIST_DENSITY * drift * nvMul
                              * (1.0 - cave) * (1.0 + 0.5 * rain);
            T2 = mistDensity * heightIntegral(cameraPosition.y, worldDir.y, d, FOG_HEIGHT_BASE, 1.0 / MIST_FALLOFF);
        }

        float T = T1 + T2;
        vec3 fc = (fogCol * T1 + mistCol * T2) / max(T, 0.00001);
        float fog = 1.0 - exp(-T);
        color = mix(color, fc, clamp(fog, 0.0, 1.0));
    }

    // ---- Ceu: puxa para a cor da nevoa perto do horizonte ----
    if (isSky) {
        float horizon = 1.0 - smoothstep(-0.02, 0.35, worldDir.y);
        float skyMix  = SKY_FOG_STRENGTH * mix(0.35, 1.0, horizon);
        skyMix += 0.15 * rain;
#if defined NEVOA_NETHER
        skyMix = 1.0;
#endif
        if (isEyeInWater == 1) skyMix = 1.0;
        color = mix(color, skyFogCol, clamp(skyMix, 0.0, 1.0));
    }

    // ---- Color grading ----
#ifdef COLOR_TINT
    vec3 tint = mix(TINT_DAY, TINT_NIGHT, night);
    color *= mix(vec3(1.0), tint, TINT_STRENGTH);
#endif

    float lum = dot(color, LUMA);
    color = mix(color, vec3(lum), DESATURATION);

    // Gamma lift (levanta os escuros para a caverna continuar legivel)
    color = pow(max(color, vec3(0.0)), vec3(1.0 / GAMMA_LIFT));

    // Contraste em torno de um pivo baixo
    color = (color - 0.3) * CONTRAST + 0.3;

    // ---- Vinheta suave (sem barras pretas) ----
#ifdef VIGNETTE
    float vd = distance(texCoord, vec2(0.5)) * 1.41421356;
    color *= 1.0 - VIGNETTE_STRENGTH * smoothstep(0.4, 1.3, vd);
#endif

    // Dither de 1/255 (estatico, invisivel) so para evitar banding na nevoa escura
#ifdef DITHER
    float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    color += (n - 0.5) / 255.0;
#endif

    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
