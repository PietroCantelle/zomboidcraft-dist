// ZomboidCraft Névoa — shader leve do ZomboidCraft
// Passe único de pós-processamento: lê colortex0 (cena vanilla) e depthtex0,
// aplica névoa exponencial por altura, paleta de horror, dessaturação,
// gamma lift, contraste e vinheta suave. Sem shadow map, sem buffers extras,
// sem TAA, sem bloom, sem grão.
//
// Incluído por composite.fsh de cada dimensão, que define antes:
//   NEVOA_OVERWORLD | NEVOA_NETHER | NEVOA_END

#include "/lib/options.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

uniform int worldTime;
uniform float rainStrength;
uniform float nightVision;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;

varying vec2 texCoord;

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

// ---- Paletas (presets) ----
#if FOG_DAY_PRESET == 1
const vec3 FOG_DAY_COLOR = vec3(0.47, 0.48, 0.50);      // Chumbo (cinza neutro)
#elif FOG_DAY_PRESET == 2
const vec3 FOG_DAY_COLOR = vec3(0.38, 0.47, 0.38);      // Pantano (verde)
#elif FOG_DAY_PRESET == 3
const vec3 FOG_DAY_COLOR = vec3(0.50, 0.46, 0.40);      // Cinza morto (sepia)
#else
const vec3 FOG_DAY_COLOR = vec3(0.46, 0.52, 0.49);      // Nevoa fria (cinza-esverdeado)
#endif

#if FOG_NIGHT_PRESET == 1
const vec3 FOG_NIGHT_COLOR = vec3(0.012, 0.012, 0.015); // Breu
#elif FOG_NIGHT_PRESET == 2
const vec3 FOG_NIGHT_COLOR = vec3(0.015, 0.045, 0.035); // Verde doentio
#elif FOG_NIGHT_PRESET == 3
const vec3 FOG_NIGHT_COLOR = vec3(0.055, 0.015, 0.012); // Sangue velho
#else
const vec3 FOG_NIGHT_COLOR = vec3(0.020, 0.035, 0.060); // Azul abissal
#endif

const vec3 FOG_CAVE_COLOR   = vec3(0.012, 0.014, 0.018);
const vec3 FOG_WATER_COLOR  = vec3(0.020, 0.080, 0.090);
const vec3 FOG_NETHER_COLOR = vec3(0.160, 0.050, 0.030);
const vec3 FOG_END_COLOR    = vec3(0.050, 0.030, 0.070);

const vec3 TINT_DAY   = vec3(0.94, 1.00, 0.97);
const vec3 TINT_NIGHT = vec3(0.86, 0.94, 1.06);

// Densidade base: ~50% de nevoa a 58 blocos de dia (FOG_DENSITY 1.0)
const float BASE_DENSITY = 0.012;

/* DRAWBUFFERS:0 */

void main() {
    vec3 color  = texture2D(colortex0, texCoord).rgb;
    float depth = texture2D(depthtex0, texCoord).r;

    // Posicao em view-space a partir da profundidade
    vec4 viewPos = gbufferProjectionInverse * vec4(vec3(texCoord, depth) * 2.0 - 1.0, 1.0);
    viewPos.xyz /= viewPos.w;
    float dist = length(viewPos.xyz);
    vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * viewPos.xyz);

    bool isSky  = depth > 0.9999;   // ceu: nada escrito no depth
    bool isHand = depth < 0.56;     // mao/item em primeira pessoa (depth comprimido pelo Iris)

    // ---- Fatores de ambiente ----
    float t = float(worldTime);
    float night = smoothstep(12000.0, 13500.0, t) * (1.0 - smoothstep(22500.0, 24000.0, t));
    float rain  = rainStrength;
    float skyLight = float(eyeBrightnessSmooth.y) / 240.0;
    float cave  = smoothstep(0.35, 1.0, 1.0 - skyLight);

    // ---- Cor e densidade da nevoa por dimensao ----
    vec3 fogCol;
    float density;
    bool useHeight = false;

#if defined NEVOA_NETHER
    fogCol  = FOG_NETHER_COLOR;
    density = BASE_DENSITY * 1.5 * FOG_DENSITY;
    night = 0.0;
    cave  = 0.0;
#elif defined NEVOA_END
    fogCol  = FOG_END_COLOR;
    density = BASE_DENSITY * 0.7 * FOG_DENSITY;
    night = 0.8;
    cave  = 0.0;
#else
    fogCol = mix(FOG_DAY_COLOR, FOG_NIGHT_COLOR, night);
    // chuva: mais cinza e um pouco mais escura
    fogCol = mix(fogCol, vec3(dot(fogCol, LUMA)) * 0.85, 0.5 * rain);
    density = BASE_DENSITY * FOG_DENSITY
            * (1.0 + FOG_NIGHT_BOOST * night)
            * (1.0 + FOG_RAIN_BOOST * rain);
    #ifdef HEIGHT_FOG
    useHeight = true;
    #endif
#endif

    // Cor usada no ceu (sem a mistura de caverna, para a saida da caverna continuar visivel)
    vec3 skyFogCol = fogCol;

    // Caverna / interior escuro: nevoa mais densa e quase preta
    fogCol  = mix(fogCol, FOG_CAVE_COLOR, cave);
    density *= 1.0 + FOG_CAVE_BOOST * cave;

    // Visao noturna reduz a nevoa
    density *= 1.0 - 0.6 * nightVision;

    // Debaixo da agua
    if (isEyeInWater == 1) {
        fogCol    = FOG_WATER_COLOR;
        density   = 0.09 * FOG_DENSITY;
        useHeight = false;
    }

    // ---- Nevoa na geometria ----
    if (!isSky && !isHand) {
        float d = max(dist - FOG_START, 0.0);
        float amount;
        if (useHeight) {
            // Integral analitica de densidade exponencial por altura ao longo do raio
            float b     = 1.0 / FOG_HEIGHT_FALLOFF;
            float h0    = max(cameraPosition.y - FOG_HEIGHT_BASE, 0.0);
            float dirB  = worldDir.y * b;
            float atCam = exp(-h0 * b);
            if (abs(dirB) > 0.0001) {
                amount = atCam * (1.0 - exp(min(-d * dirB, 60.0))) / dirB;
            } else {
                amount = atCam * d;
            }
            amount = max(amount, 0.0);
        } else {
            amount = d;
        }
        float fog = 1.0 - exp(-density * amount);
        color = mix(color, fogCol, clamp(fog, 0.0, 1.0));
    }

    // ---- Ceu: puxa para a cor da nevoa perto do horizonte ----
    if (isSky) {
        float horizon = 1.0 - smoothstep(-0.02, 0.35, worldDir.y);
        float skyMix  = SKY_FOG_STRENGTH * mix(0.35, 1.0, horizon);
        skyMix += 0.15 * rain;
#if defined NEVOA_NETHER
        skyMix = 1.0;
#endif
        if (isEyeInWater == 1) skyMix = 1.0;
        color = mix(color, skyFogCol, clamp(skyMix, 0.0, 1.0));
    }

    // ---- Color grading ----
#ifdef COLOR_TINT
    vec3 tint = mix(TINT_DAY, TINT_NIGHT, night);
    color *= mix(vec3(1.0), tint, TINT_STRENGTH);
#endif

    float lum = dot(color, LUMA);
    color = mix(color, vec3(lum), DESATURATION);

    // Gamma lift (levanta os escuros para a caverna continuar legivel)
    color = pow(max(color, vec3(0.0)), vec3(1.0 / GAMMA_LIFT));

    // Contraste em torno de um pivo baixo
    color = (color - 0.3) * CONTRAST + 0.3;

    // ---- Vinheta suave (sem barras pretas) ----
#ifdef VIGNETTE
    float vd = distance(texCoord, vec2(0.5)) * 1.41421356;
    color *= 1.0 - VIGNETTE_STRENGTH * smoothstep(0.4, 1.3, vd);
#endif

    // Dither de 1/255 (estatico, invisivel) so para evitar banding na nevoa escura
#ifdef DITHER
    float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    color += (n - 0.5) / 255.0;
#endif

    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
