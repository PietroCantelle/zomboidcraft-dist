#version 120

// ZomboidCraft Névoa — passe de sombra (vértice)
#include "/lib/options.glsl"
#include "/lib/shadow_common.glsl"

varying vec2 texCoord;
varying vec4 vertColor;

void main() {
    vec4 pos = gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex;
    pos.xyz = distortShadow(pos.xyz);
    gl_Position = pos;

    texCoord  = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vertColor = gl_Color;
}
