#version 120

// ZomboidCraft Névoa — passe de sombra (fragmento)
// Grava a cor (textura x cor do vértice) em shadowcolor0; a profundidade vai para shadowtex0/1.
uniform sampler2D tex;

varying vec2 texCoord;
varying vec4 vertColor;

void main() {
    vec4 albedo = texture2D(tex, texCoord) * vertColor;
    if (albedo.a < 0.1) discard;
    gl_FragData[0] = albedo;
}
