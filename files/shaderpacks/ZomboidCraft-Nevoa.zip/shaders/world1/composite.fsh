#version 120

// ZomboidCraft Névoa — End
#define NEVOA_END
#include "/lib/nevoa.glsl"
