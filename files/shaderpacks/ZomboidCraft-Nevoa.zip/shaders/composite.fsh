#version 120

// ZomboidCraft Névoa — Overworld
#define NEVOA_OVERWORLD
#include "/lib/nevoa.glsl"
