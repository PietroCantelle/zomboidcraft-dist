#version 120

// ZomboidCraft Névoa — Nether
#define NEVOA_NETHER
#include "/lib/nevoa.glsl"
